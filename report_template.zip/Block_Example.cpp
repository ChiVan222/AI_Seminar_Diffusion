#include <iostream>
#include <unordered_map>
#include <memory>
#include <string>

// Forward declaration
struct BlockContext;

// Flyweight interface
class BlockFlyweight {
public:
    virtual ~BlockFlyweight() = default;
    virtual void render(const BlockContext& context) const = 0;
    virtual void interact(const BlockContext& context) const = 0;
    virtual std::string getBlockInfo() const = 0;
};

// Context containing extrinsic state
struct BlockContext {
    int x, y, z;           // Position in world
    int currentHealth;     // Current durability
    bool isVisible;        // Visibility state
    int lightLevel;        // Current light level
    
    BlockContext(int x, int y, int z, int health = 100) 
        : x(x), y(y), z(z), currentHealth(health), 
          isVisible(true), lightLevel(15) {}
};

// Concrete Flyweight for Stone blocks
class StoneBlock : public BlockFlyweight {
private:
    // Intrinsic state (shared among all stone blocks)
    std::string texture;
    int maxHealth;
    std::string material;
    float hardness;

public:
    StoneBlock() : texture("stone_texture.png"), maxHealth(100), 
                   material("Stone"), hardness(2.0f) {}

    void render(const BlockContext& context) const override;

    void interact(const BlockContext& context) const override;

    std::string getBlockInfo() const override;
};

// Concrete Flyweight for Wood blocks
class WoodBlock : public BlockFlyweight {
private:
    std::string texture;
    int maxHealth;
    std::string material;
    float hardness;

public:
    WoodBlock() : texture("wood_texture.png"), maxHealth(60), 
                  material("Wood"), hardness(1.0f) {}

    void render(const BlockContext& context) const override;

    void interact(const BlockContext& context) const override;

    std::string getBlockInfo() const override;
};

// Concrete Flyweight for Dirt blocks
class DirtBlock : public BlockFlyweight {
private:
    std::string texture;
    int maxHealth;
    std::string material;
    float hardness;

public:
    DirtBlock() : texture("dirt_texture.png"), maxHealth(30), 
                  material("Dirt"), hardness(0.5f) {}

    void render(const BlockContext& context) const override;

    void interact(const BlockContext& context) const override;

    std::string getBlockInfo() const override;
};

// Flyweight Factory
class BlockFlyweightFactory {
private:
    std::unordered_map<std::string, std::shared_ptr<BlockFlyweight>> flyweights;
    
public:
    std::shared_ptr<BlockFlyweight> getFlyweight(const std::string& blockType);
    
    size_t getCreatedFlyweightsCount() const;
    
    void listCreatedFlyweights() const;
};

// Game World that manages blocks
class GameWorld {
private:
    BlockFlyweightFactory factory;
    std::vector<std::pair<std::shared_ptr<BlockFlyweight>, BlockContext>> blocks;
    
public:
    void placeBlock(const std::string& blockType, int x, int y, int z);
    
    void renderAllBlocks() const;
    
    void interactWithBlock(size_t index);
    
    void damageBlock(size_t index, int damage);
    
    void printStatistics() const;
};

